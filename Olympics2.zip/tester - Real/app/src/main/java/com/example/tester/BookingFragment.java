package com.example.tester;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BookingFragment extends Fragment {
    View v;
    RecyclerView recyclerView;

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.fragment_booking, container, false);
        recyclerView = v.findViewById(R.id.recyclerViewId);
        recyclerView.setAdapter(new Adapter());
        return v;

    }


    public class Adapter extends RecyclerView.Adapter<Holder> {

        @NonNull
        @Override
        public Holder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
            View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rowbook, null);
            return new Holder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull final Holder holder, int i) {
            holder.Btime.setText("time");
            holder.Bevent.setText("Event");
            holder.Btype.setText("type");

        }


        @Override
        public int getItemCount() {
            return 1;
        }


    }
    public class Holder extends RecyclerView.ViewHolder {

        TextView Btime,Bevent,Btype;

        Holder(@NonNull View itemView) {
            super(itemView);

            this.Btime = itemView.findViewById(R.id.time);
            this.Bevent = itemView.findViewById(R.id.Event);
            this.Btype = itemView.findViewById(R.id.type);

        }

    }

}



