package com.example.tester;


public class BusModel {

    private  String left,type,time;
    private int numseat;
    private String description;

    public String getTime(){

        return time;
    }

    public void setTime(String time){
        this.time = time;

    }

    public String getLeft(){

        return left;
    }

    public void setLeft(String left){

        this.left = left;
    }
    public String getType(){

        return type;
    }

    public void setType(String type){

        this.type = type;
    }
    public int getNumseat() {

        return numseat;
    }

    public void setNumseat(int num) {

        this.numseat = num;
    }
    // UPDATE
    public void setDescription(String description){
        this.description = description;
    }
    public String getDescription(){
        return description;
    }

}
