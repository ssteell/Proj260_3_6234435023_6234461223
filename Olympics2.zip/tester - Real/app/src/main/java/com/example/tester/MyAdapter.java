package com.example.tester;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.drawable.BitmapDrawable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.io.ByteArrayOutputStream;
import java.util.ArrayList;

public class MyAdapter extends RecyclerView.Adapter<MyHolder> {

    Context c;
    ArrayList<Model> models;

    public MyAdapter(ArrayList<Model> models, Context c ){
        this.c  = c;
        this.models =models;

    }

    @NonNull
    @Override
    public MyHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.row, null);

        return new MyHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final MyHolder holder, int i) {

        holder.mTitle.setText(models.get(i).getTitle());
        holder.mDes.setText(models.get(i).getDescription());
        holder.mImageView.setImageResource(models.get(i).getImg());


        holder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickListener(View v, int position) {
                if(models.get(position).getTitle().equals("SWIMMING")){
                    callAnotherActivity(holder, position);
                }
                if(models.get(position).getTitle().equals("RUNNING")){
                    callAnotherActivity(holder, position);
                }
                if(models.get(position).getTitle().equals("SAILING")){
                    callAnotherActivity(holder, position);
                }
            }
        });

    }

    private void callAnotherActivity(MyHolder holder, int position){
        String gTitle = models.get(position).getTitle();
        String gDes = models.get(position).getDescription();
        String gVenue = models.get(position).getVenue();
        String gDate = models.get(position).getDate();
        String gStart = models.get(position).getStart();
        String gDuration = models.get(position).getDuration();
        String gTravel = models.get(position).getTravel();
        BitmapDrawable bitmapDrawable = (BitmapDrawable) holder.mImageView.getDrawable();
        Bitmap bitmap = bitmapDrawable.getBitmap();

         ByteArrayOutputStream stream  = new ByteArrayOutputStream();

         bitmap.compress(Bitmap.CompressFormat.PNG,100,stream);

         byte[] bytes =stream.toByteArray();

        Intent intent = new Intent(c,activity_another_1.class);

        intent.putExtra("iTitle",gTitle);
        intent.putExtra("iDes",gDes);
        intent.putExtra("iVenue",gVenue);
        intent.putExtra("iDate",gDate);
        intent.putExtra("iStart",gStart);
        intent.putExtra("iDuration",gDuration);
        intent.putExtra("iTravel",gTravel);
        intent.putExtra("iImage",bytes);
        c.startActivity(intent);




    }

    @Override
    public int getItemCount() {
        return models.size();
    }


}