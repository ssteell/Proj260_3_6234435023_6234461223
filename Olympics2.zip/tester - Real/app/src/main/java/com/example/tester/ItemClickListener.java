package com.example.tester;

import android.view.View;

public interface ItemClickListener {
    void onItemClickListener(View v, int position);
}
