package com.example.tester;

public class Model {

    private String title,description,Venue,Date,Start,Duration,Travel;
    private int img;

    public String getTitle(){
        return title;
    }

    public void setTitle(String title){
        this.title = title;
    }

    public String getDescription(){
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getVenue(){
        return Venue;
    }

    public void setVenue(String s){
        this.Venue = s;
    }
    public String getDate(){
        return Date;
    }

    public void setDate(String s){
        this.Date = s;
    }
    public String getStart(){
        return Start;
    }

    public void setStart(String s){
        this.Start = s;
    }
    public String getDuration(){
        return Duration;
    }

    public void setDuration(String s){
        this.Duration = s;
    }
    public String getTravel(){
        return Travel;
    }

    public void setTravel(String s){
        this.Travel = s;
    }

    public int getImg() {
        return img;
    }

    public void setImg(int img) {
        this.img = img;
    }


  }
