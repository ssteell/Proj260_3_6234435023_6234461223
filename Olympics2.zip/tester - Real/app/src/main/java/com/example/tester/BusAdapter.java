package com.example.tester;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BusAdapter extends RecyclerView.Adapter<BusHolder> {

    Context c;
    ArrayList<BusModel> models;

    public BusAdapter(Context c, ArrayList<BusModel> models){
        this.c = c;
        this.models = models;

    }

    @NonNull
    @Override
    public BusHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rowbus,null);
        return new BusHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final BusHolder busholder, int i) {
        busholder.Btime.setText(models.get(i).getTime());
        busholder.Bleft.setText(models.get(i).getLeft());
        busholder.Btype.setText(models.get(i).getType());

        // ---- Update
        busholder.setItemClickListener(new ItemClickListener() {
            @Override
            public void onItemClickListener(View v, int position) {
                if(models.get(position).getType().equals("TypeA")){
                    callAnotherActivity(busholder, position);
                }
                if(models.get(position).getType().equals("TypeB")){
                    callAnotherActivity(busholder, position);
                }
                if(models.get(position).getType().equals("TypeC")){
                    callAnotherActivity(busholder, position);
                }
            }
        });
    }

    private void callAnotherActivity(BusHolder busHolder, int position){
        String description = models.get(position).getDescription();
        String time = models.get(position).getTime();
        String type = models.get(position).getType();
        String left = models.get(position).getLeft();

        Intent in = new Intent(c, Busbook.class);
        in.putExtra("DESCRIPTION", description);
        in.putExtra("TIME", time);
        in.putExtra("TYPE", type);
        in.putExtra("LEFT", left);
        c.startActivity(in);
    }

    @Override
    public int getItemCount() {

        return models.size();
    }


}
