package com.example.tester;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;

public class Busbook extends AppCompatActivity {
    Button book;
    TextView con,event,Ttype;
    java.util.Random Random = new Random();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_busbook);

        event = findViewById(R.id.Event_show);
        Ttype = findViewById(R.id.Ttype);
        book = findViewById(R.id.bookk);
        con = findViewById(R.id.popup);


        Intent in = getIntent();
        final String type = in.getStringExtra("TYPE");
        final String mTitle = in.getStringExtra("DESCRIPTION");
        final String Time = in.getStringExtra("TIME");

        final String S1 = Seat(1);
        event.setText(mTitle);
        Ttype.setText(type);

        book.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AlertDialog.Builder builder = new AlertDialog.Builder(Busbook.this);

                builder.setCancelable(true);
                builder.setTitle("Confirm Booking");
                builder.setMessage("Bus: " +type+"\nTime: "+Time+"\nSeat: "+S1+"\n"+mTitle+"\nDestination: Tokyo Stadium");

                builder.setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        dialog.cancel();
                    }
                });

                builder.setPositiveButton("Confirm", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int i) {
                        Intent intent = new Intent(Busbook.this, MainActivity.class);
                        startActivity(intent);
                    }
                });
                builder.show();
            }
        });
    }
    private String Seat(int i) {
        char[] chars = "ABCD".toCharArray();
        StringBuilder stringBuilder = new StringBuilder();
        for (int k = 0; k < 1; k++) {
            char c = chars[Random.nextInt(chars.length)];
            stringBuilder.append(c);
        }
        int num1 = Random.nextInt(5) + 1;
        return num1 + stringBuilder.toString();
    }
}
