package com.example.tester;

import android.content.Intent;
import android.view.View;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class BusHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

    TextView Btime,Bleft,Btype;
    ItemClickListener itemClickListener;
    BusHolder(@NonNull View itemView) {
        super(itemView);

        this.Btime = itemView.findViewById(R.id.time);
        this.Bleft = itemView.findViewById(R.id.left);
        this.Btype = itemView.findViewById(R.id.type);

        itemView.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        this.itemClickListener.onItemClickListener(v, getLayoutPosition());
    }

    public void setItemClickListener(ItemClickListener itemClickListener) {
        this.itemClickListener = itemClickListener;
    }
}
