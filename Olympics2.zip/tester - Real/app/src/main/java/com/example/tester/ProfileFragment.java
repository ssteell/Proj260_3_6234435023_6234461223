package com.example.tester;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.example.tester.Model_login.Users;
import com.google.android.gms.common.util.SharedPreferencesUtils;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

public class ProfileFragment extends Fragment {

    FirebaseDatabase database;
    DatabaseReference userRef;
    private static final String USERS = "Users";

    private TextView UserID, CardNo, Name;
        View v;

    public ProfileFragment() {

    }

    public static ProfileFragment newInstance(){
        return new ProfileFragment();
    }


    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable final ViewGroup container, @Nullable Bundle savedInstanceState) {

        v = inflater.inflate(R.layout.fragment_profile, container, false);
        Name= (TextView) v.findViewById(R.id.u_name);
        CardNo = (TextView) v.findViewById(R.id.u_cardno);
        UserID = (TextView) v.findViewById(R.id.u_username);

        //Intent intent = getIntent();
        //final String userid = intent.getStringExtra("userid");


        database =FirebaseDatabase.getInstance();
        userRef = database.getReference(USERS);



        userRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                SharedPreferences sp = getActivity().getSharedPreferences("KEY_USERNAME", Context.MODE_PRIVATE);
                String userid = sp.getString("USERID","");
                //Users users = dataSnapshot.getValue(Users.class);

                for(DataSnapshot ds : dataSnapshot.getChildren()) {
                   if (ds.child("userid").getValue().equals(userid)) {
                       String name = "Your name : " + ds.child("name").getValue();
                       String username = "Username : " + ds.child("userid").getValue();
                       String cardno = "Card number : " + ds.child("cardno").getValue();
                       Name.setText(name);
                       UserID.setText(username);
                       CardNo.setText(cardno);
                   }
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


        Button logout = (Button) v.findViewById(R.id.btn_logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getActivity(),LoginActivity.class);
                startActivity(intent);
            }
        });
        return v;}


}



