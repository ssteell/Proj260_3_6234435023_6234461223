package com.example.tester;

import androidx.annotation.Nullable;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class activity_another_1 extends AppCompatActivity {
    public static final String EXTRA_DETAIL = "extra_detail";
    ImageView imageViewIV;
    TextView mTitleTV , mDesTV,mVenueTV,mDateTV,mStartTV,mDurationTV,mTravelTV;
    Button bnt_booknow;
    ItemClickListener itemClickListener;
    String title;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_another_1);

        ActionBar actionBar = getSupportActionBar();

        mTitleTV = findViewById(R.id.textView1);
        mDesTV = findViewById(R.id.textView2);
        imageViewIV = findViewById(R.id.imageView);
        mVenueTV = findViewById(R.id.venue);
        mDateTV = findViewById(R.id.date);
        mStartTV  = findViewById(R.id.start_time);
        mDurationTV = findViewById(R.id.duration);
        mTravelTV =findViewById(R.id.travel);
        bnt_booknow = findViewById(R.id.bnt_booknow);

        Intent intent = getIntent();
        String mTitle = intent.getStringExtra("iTitle");
        title = mTitle;
        String mDescription = intent.getStringExtra("iDes");
        String mVenue = intent.getStringExtra("iVenue");
        String mDate = intent.getStringExtra("iDate");
        String mStart = intent.getStringExtra("iStart");
        String mDuration = intent.getStringExtra("iDuration");
        String mTravel = intent.getStringExtra("iTravel");

        byte[] mBytes = getIntent().getByteArrayExtra("iImage");

        Bitmap bitmap = BitmapFactory.decodeByteArray(mBytes,0,mBytes.length);
        actionBar.setTitle(mTitle);
        mTitleTV.setText(mTitle);
        mDesTV.setText(mDescription);
        mVenueTV.setText(mVenue);
        mDateTV.setText(mDate);
        mStartTV.setText(mStart);
        mDurationTV.setText(mDuration);
        mTravelTV.setText(mTravel);
        imageViewIV.setImageBitmap(bitmap);

        bnt_booknow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(activity_another_1.this, BusTime.class);
                intent.putExtra("TITLE", title);
                startActivity(intent);
            }
        });
    }
}
