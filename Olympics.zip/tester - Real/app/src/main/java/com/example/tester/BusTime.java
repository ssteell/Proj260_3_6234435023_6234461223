package com.example.tester;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.TextView;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BusTime extends AppCompatActivity {

    RecyclerView bRecyclerView;
    BusAdapter busAdapter;
    TextView To;
    private int timeEvent;
    private int seat;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_bustime);

        bRecyclerView = findViewById(R.id.recyclerViewId);
        To = findViewById(R.id.busto);

        ActionBar actionBar = getSupportActionBar();

        Intent intent = getIntent();
        String bTitle = intent.getStringExtra("TITLE");

        if(bTitle.equals("SWIMMING")){
            timeEvent = 14;
            To.setText("Buses to Swimming Preliminary Round \nWomen");
        }
        else if(bTitle.equals("RUNNING")){
            timeEvent = 15;
            To.setText("Buses to Running Preliminary Round \nMen");
        }
        else if(bTitle.equals("SAILING")){
            timeEvent = 16;
            To.setText("Buses to Sailing Preliminary Round \nWomen");
        }

        busAdapter = new BusAdapter(this,getBusList());
        bRecyclerView.setAdapter(busAdapter);
        bRecyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    private ArrayList<BusModel> getBusList() {

        ArrayList<BusModel> models = new ArrayList<>();

        BusModel m = new BusModel();
        m.setTime((timeEvent-2)+":30 -"+(timeEvent-1)+":00 น.");
        m.setType("TypeA");
        m.setLeft("20 out of 20 left");
        models.add(m);

        m = new BusModel();
        m.setTime((timeEvent-1)+":00 -"+(timeEvent-1)+":30 น.");
        m.setType("TypeB");
        m.setLeft("10 out of 10 left");
        models.add(m);

        m = new BusModel();
        m.setTime((timeEvent)+":30 -"+(timeEvent+1)+":00 น.");
        m.setType("TypeB");
        m.setLeft("10 out of 10 left");
        models.add(m);

        return models;
    }

}
