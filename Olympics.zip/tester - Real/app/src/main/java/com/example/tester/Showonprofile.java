package com.example.tester;

public class Showonprofile extends ProfileFragment {
    private String name;
    private String username;
    private String cardno;

    public Showonprofile(){

    }

    public  String getName_pf() {

        return name;
    }

    public  String getUsername_pf() {
        return username;
    }

    public  String getCardno_pf() {
        return cardno;
    }


    public Showonprofile(String name, String username, String cardno){
        this.name = name;
        this.username =username;
        this.cardno =cardno;


    }

}
