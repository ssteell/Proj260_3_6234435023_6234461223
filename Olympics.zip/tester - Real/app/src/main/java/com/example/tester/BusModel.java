package com.example.tester;

import android.content.Intent;

public class BusModel {

    private  String left,type,time;
    private int img;

    public String getTime(){

        return time;
    }

    public void setTime(String time){
        this.time = time;

    }

    public String getLeft(){

        return left;
    }

    public void setLeft(String left){

        this.left = left;
    }
    public String getType(){

        return type;
    }

    public void setType(String type){

        this.type = type;
    }
    public int getImg() {

        return img;
    }

    public void setImg(int img) {

        this.img = img;
    }
}
