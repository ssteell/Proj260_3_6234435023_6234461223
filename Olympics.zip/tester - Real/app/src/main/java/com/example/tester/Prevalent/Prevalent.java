package com.example.tester.Prevalent;


import com.example.tester.Model_login.Users;

public class Prevalent
{
    private static Users currentOnlineUser;
}
