package com.example.tester;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RelativeLayout;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class BusAdapter extends RecyclerView.Adapter<BusHolder> {

    Context c;
    ArrayList<BusModel> models;


    public BusAdapter(Context c, ArrayList<BusModel> models){
        this.c = c;
        this.models = models;

    }


    @NonNull
    @Override
    public BusHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.rowbus,null);
        return new BusHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull BusHolder busholder, int i) {
        BusHolder.Btime.setText(models.get(i).getTime());
        BusHolder.Bleft.setText(models.get(i).getLeft());
        BusHolder.Btype.setText(models.get(i).getType());

        

    }


    @Override
    public int getItemCount() {
        return models.size();
    }
}
