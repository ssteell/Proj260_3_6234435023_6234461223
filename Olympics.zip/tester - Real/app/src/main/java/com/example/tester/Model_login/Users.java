package com.example.tester.Model_login;

public class Users {
    private String name,username,password,cardno;

    public Users(){

    }

    public String getName_lg() {
        return name;
    }

    public String getUsername_lg() {
        return username;
    }

    public String getPassword_lg() {
        return password;
    }

    public String getCardno_lg() {
        return cardno;
    }

    public void setName_lg(String name) {
        this.name = name;
    }

    public void setUsername_lg(String username) {
        this.username = username;
    }

    public void setPassword_lg(String password) {
        this.password = password;
    }

    public void setCardno_lg(String cardno) {
        this.cardno = cardno;
    }

    public Users(String name, String username, String password, String cardno){
       this.setName_lg(name);
        this.username =username;
        this.password =password;
        this.cardno =cardno;

    }
}


