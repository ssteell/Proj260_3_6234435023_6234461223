package com.example.tester;

import android.view.View;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;


public class BusHolder extends RecyclerView.ViewHolder {
    static TextView Btime,Bleft,Btype;
    ItemClickListener itemClickListener;
    RelativeLayout bustime;
    BusHolder(@NonNull View itemView) {
        super(itemView);

        this.Btime = itemView.findViewById(R.id.time);
        this.Bleft = itemView.findViewById(R.id.left);
        this.Btype = itemView.findViewById(R.id.type);
        bustime = itemView.findViewById(R.id.recyclerViewId);
    }
}
